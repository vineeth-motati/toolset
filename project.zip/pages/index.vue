<template>
  <div class="max-w-4xl mx-auto">
    <h1 class="text-4xl font-bold text-center mb-8">
      Welcome to MultiTools Hub
    </h1>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div
        v-for="tool in tools"
        :key="tool.path"
        class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
      >
        <NuxtLink :to="tool.path">
          <h2 class="text-xl font-semibold mb-2">{{ tool.name }}</h2>
          <p class="text-gray-600">{{ tool.description }}</p>
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup>
const tools = [
  {
    name: 'Kanban Board',
    path: '/tools/kanban',
    description: 'Organize your tasks with a drag-and-drop Kanban board',
  },
  {
    name: 'Notes',
    path: '/tools/notes',
    description: 'Take and organize your notes with markdown support',
  },
  {
    name: 'Code Editor',
    path: '/tools/code',
    description: 'Write and share code with syntax highlighting',
  },
  {
    name: 'QR Generator',
    path: '/tools/qr',
    description: 'Generate QR codes for any text or URL',
  },
  {
    name: 'Image Tools',
    path: '/tools/image',
    description: 'Compress and optimize your images',
  },
];
</script>
